1. Place 'median_of_medians.py', 'hybrid_sorting.py', and 'unsorted_list.txt' files in one folder.
2. Launch the command line from this folder.
3. Run Python script with parameters written in the HW manual. 

For example: 
E:\Your_folder>python hybrid_sorting.py unsorted_list.txt sorted_list.txt 1 1 2 1
E:\Your_folder>python median_of_medians.py unsorted_list.txt 6 9

